# VALDO X20 — Atelier V10 (27/10/2026)

**Estado: DEMOSTRADOR DIGITAL, NO OEM, NO FABRICAR.**

## Objetivo y problema resuelto

Tras la V09, el núcleo aliviado tenía contactos muy pequeños a ±2 mm de posición lateral al elevar las mopas 12 mm. El modelo V10 extiende el alivio de cada mopa de radio 49,5 mm a **51,05 mm**, conservando el techo geométrico de 1,2 mm debajo de los bolsillos de alineación vertical posterior. No modifica la superficie externa de la carrocería.

La ampliación consume alrededor del **0,666 % del volumen del núcleo V09**. Eso es solo volumen CAD, no una garantía de rigidez.

## Ensayos CAD ejecutados

- **Construcción:** 258 estados de movimiento de proxies: 250 configuraciones de mopa y 8 de ruedas/cepillo, todos sin interpenetración entre móviles y núcleo/puentes del escenario.
- **Validación independiente:** **696 ensayos**, comparando exactamente las mismas poses en V09 y V10. Para ±2 mm XY y elevación 12 mm: V09 4/50 estados con contacto, V10 0/50.
- Para 11, 12, 12,5 y 13 mm V10 obtuvo 0/50 contactos por altura, pero **solo se acepta como margen el caso ≤12 mm**, que conserva el margen vertical nominal de 1,2 mm.
- Elevaciones de 13,5/14 mm: V10 50/50 estados con contacto. NO declarar carrera superior válida.
- A ±3 mm XY y elevación 12 mm: V10 todavía da 2/48 estados con contacto, otra frontera comprobada.
- 8 puentes de alineación sin contacto estático, 22 posiciones ascendentes de extracción de las dos pasarelas traseras sin penetración.
- FreeCAD GUI real: vistas exterior, despiece y volumen de despeje, guardadas en FCStd; las **tres se han vuelto a abrir** y renderizado desde FreeCAD.
- Exportación STEP: 48 piezas exteriores y 104 componentes conceptuales. El conjunto completo ha sido reimportado y se han detectado al menos 104 sólidos.

## Archivos útiles

**Abre primero** `VALDO_X20_V10_EXTERIOR_GUI.FCStd` (aspecto exterior) o `VALDO_X20_V10_DESPIECE_GUI.FCStd` (tapa levantada únicamente para ilustración).

`VALDO_X20_V10_MOPAS_DESPEJE_GUI.FCStd`: visualiza las mopas sintéticas y dos volúmenes transparentes que **no son piezas físicas**; el área es una reserva para movimiento asumido.

`VALDO_X20_V10_DESPEJE_LATERAL_NUCLEO_NO_FABRICAR.FCStd`: fuente mecánica sin geometría fantasma añadida.

`VALDO_X20_V10_EXTERIOR_CONCEPTO_NO_FABRICAR.step` y `VALDO_X20_V10_104_PIEZAS_CONCEPTUALES_NO_FABRICAR.step`: intercambio CAD, no para impresión.

`VALDO_X20_V10_LAMINA_COMPARATIVA.png`: lámina técnica de cuatro paneles creada a partir de capturas auténticas de FreeCAD y datos OCC de los ensayos.

`build_v10.py`, `auditoria_independiente_v10.py`, `VALIDACION_V10.json`, `AUDITORIA_INDEPENDIENTE_V10.json` y `STEP_VALIDACION_V10.json`: reproducción y evidencias.

## Límites que bloquean la aprobación

1. M29 y otras dimensiones de mopas, 6DOF y recorrido de la unidad Xiaomi sin medir; no existe seguridad de que el movimiento supuesto coincida con el OEM.
2. Ni el grosor de pared conservado ni los pasadores/pasarelas están ensayados a flexión, golpes, fatiga, humedad o desgaste. Los **cierres retenedores** siguen siendo del compañero de ese sector.
3. Están pendientes la revisión global de flujos de aire, cableado, transmisión real, suspensión, potencia WPT y acoplamiento a la estación.
4. Por encima de 12 mm (con margen vertical) habría que rediseñar las pasarelas/estructura de carga trasera; no adelgazar más el núcleo sin una ruta estructural alternativa. Una ausencia de penetración CAD no certifica una junta funcional.

Se ha trabajado en carpeta independiente. Las versiones V06/V07/V08/V09 originales y el CAD maestro compartido **permanecen intactos**. No se tocó firmware, electrónica ni robot físico.
