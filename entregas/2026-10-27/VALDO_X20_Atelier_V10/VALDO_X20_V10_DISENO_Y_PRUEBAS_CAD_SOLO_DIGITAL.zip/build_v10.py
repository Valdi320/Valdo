# -*- coding: utf-8 -*-
"""V10: incremento controlado del despeje lateral de mopas sin sacrificar
la pared vertical del bolsillo de puente trasero. Solo geometría de escenario.
Partir del V09, no reescribir el trabajo de sus autores.
"""
from pathlib import Path
import json,hashlib,math
import FreeCAD as App, Part
from FreeCAD import Vector
R=Path("/var/home/Valdi/Documentos/X20ProAbierto/Valdo/research/2026-10-25-xiaomi-x20-pro/cad/diseno_industrial_v10_20261027")
SOURCE=R.parent/"diseno_industrial_v09_20261027/VALDO_X20_V09_NUCLEO_CON_ALIVIOS_CONCEPTUAL.FCStd"
DEST=R/"VALDO_X20_V10_DESPEJE_LATERAL_NUCLEO_NO_FABRICAR.FCStd"
assert SOURCE.is_file() and not DEST.exists()
source_sha=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
doc=App.openDocument(str(SOURCE))
doc.Label="VALDO X20 V10 | Despeje lateral de mopas sin degradar techo de anclaje"
core=[doc.getObject("NucleoSector"+str(i)) for i in range(1,5)]
shell=[doc.getObject("PanelCarroceria"+str(i)) for i in range(1,5)]
bridges=[doc.getObject("V07PuenteShell"+str(i)) for i in range(1,5)]+[
 doc.getObject("V07PuenteCore1"),doc.getObject("V07PuenteCore4"),
 doc.getObject("V09PasarelaAlta2"),doc.getObject("V09PasarelaAlta3")]
assert all(core) and all(shell) and all(bridges)
before={o.Name:o.Shape.Volume for o in core}
# Extreme xy +/-2 mm en una geometria plana nominal, con margen radial adicional.
mop_pad_radius_mm=47.0
max_xy_offset_mm=2.0
extra_nominal_clearance_mm=1.2
expected_swept_R=mop_pad_radius_mm+math.sqrt(2)*max_xy_offset_mm
cut_R=51.05
assert cut_R>expected_swept_R+extra_nominal_clearance_mm # => ~1.22 mm
z0=20.45
top=24.50 # conservar techo 1.2 sobre bolsillos que arrancan z25.7
roof_min=25.70-top
assert roof_min>=1.2-1e-9
centers=[(-95.,65.),(-95.,-65.)]
cutters=[Part.makeCylinder(cut_R,top-z0,Vector(x,y,z0)) for x,y in centers]
for o in core:
 s=o.Shape.copy()
 for tool in cutters:
  if s.BoundBox.intersect(tool.BoundBox):
   s=s.cut(tool).removeSplitter()
 if s.isNull() or not s.isValid() or len(s.Solids)!=1 or s.Volume<1500:
  raise RuntimeError("Nucleo dividido o invalido: "+o.Name)
 o.Shape=s
# Un nuevo objeto informativo no convierte esta geometria en pieza producible.
g=doc.addObject("App::DocumentObjectGroup","V10EstudioRobustez")
g.Label="V10 | Despeje lateral 2mm, elevacion max 12mm, no OEM"
msg=[
 "No afirmar que 2mm/12mm son dimensiones ni movimientos Xiaomi: escenario de ingenieria.",
 "La geometria presenta puentes sin captura positiva: cierres y tolerancias reservados a otro equipo.",
 "No aumentar elevacion a 14mm sin replantear anclajes de pasarela; techo bajo bolsillo quedaria insuficiente.",
 "Cambios de material y cota de union del nucleo no certifican FEM, friccion, vida util ni estanqueidad."
]
for i,s in enumerate(msg):
 n=doc.addObject("App::DocumentObjectGroup","V10Aviso"+str(i))
 n.Label="[PENDIENTE] "+s[:70]
 n.addProperty("App::PropertyString","MensajeCompleto","Evidencia")
 n.MensajeCompleto=s;g.addObject(n)
doc.recompute()
# Digital stress grid: ±2 mm around each MopaPad (hub also checked), Z=0,3,6,9,12.
comparisons=[]
collision=[]
pose_grid=[(dx,dy,dz) for dx in (-2,-1,0,1,2) for dy in (-2,-1,0,1,2) for dz in (0,3,6,9,12)]
for mop,objs in [("left",["MopPadL","MopHubL"]),("right",["MopPadR","MopHubR"])]:
 for dx,dy,dz in pose_grid:
  hits=[];shortest=None
  for name in objs:
   part=doc.getObject(name)
   if part is None:raise RuntimeError("Missing mop "+name)
   sh=part.Shape.copy()
   sh.translate(Vector(dx,dy,dz))
   for target in core+bridges:
    if not sh.BoundBox.intersect(target.Shape.BoundBox):continue
    vol=sh.common(target.Shape).Volume
    if vol>.0008:
     hits.append({"moved":name,"target":target.Name,"volume_mm3":round(vol,6)})
  case={"side":mop,"xyz_mm":[dx,dy,dz],"collisions":hits}
  comparisons.append(case)
  if hits:collision.append(case)
# Limit stability on the other original 98 cases, with wheel ride +/-8 and +12.
for names,zz in [
  (("NeumaticoL","CartuchoL"),(-8,0,12)),
  (("NeumaticoR","CartuchoR"),(-8,0,12)),
  (("BrushRoll","BrushChannel"),(0,6))]:
 for dz in zz:
  hit=[]
  for name in names:
   part=doc.getObject(name)
   sh=part.Shape.copy();sh.translate(Vector(0,0,dz))
   for target in core+bridges:
    if sh.BoundBox.intersect(target.Shape.BoundBox):
     vol=sh.common(target.Shape).Volume
     if vol>.0008:hit.append({"moved":name,"target":target.Name,"volume":round(vol,5)})
  comparisons.append({"side":"+ ".join(names),"xyz_mm":[0,0,dz],"collisions":hit})
  if hit:collision.append(comparisons[-1])
# Static bridge mating separation and service extraction:
junctions=[]
for bridge in bridges:
 for parent in core+shell:
  if bridge.Shape.BoundBox.intersect(parent.Shape.BoundBox):
   vol=bridge.Shape.common(parent.Shape).Volume
   if vol>.001:junctions.append((bridge.Name,parent.Name,vol))
# Check upward extraction for two V09 rear top bridges.
service=[]
for name in ("V09PasarelaAlta2","V09PasarelaAlta3"):
 b=doc.getObject(name)
 for dz in (0,.5,1,2,3,4,5,6,8,10,12):
  s=b.Shape.copy();s.translate(Vector(0,0,dz))
  v=sum(s.common(p.Shape).Volume for p in core)
  service.append({"bridge":name,"upward_mm":dz,"overlap_mm3":round(v,6)})
doc.recompute()
assert not collision,("Motion collisions",collision[:5])
assert not junctions,("Bridge-parent collisions",junctions)
assert all(x["overlap_mm3"]<.001 for x in service)
after={o.Name:o.Shape.Volume for o in core}
source_pct=100*sum(after.values())/sum(before.values())
assert source_pct>95,("Volume erosion too large",source_pct)
doc.saveAs(str(DEST))
App.closeDocument(doc.Name)
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==source_sha
check=App.openDocument(str(DEST))
check.recompute()
assert all(check.getObject(n) and check.getObject(n).Shape.isValid() for n in after)
App.closeDocument(check.Name)
res={
 "ok":True,"scope":"CAD_PROXY_NON_OEM_NON_FABRICABLE",
 "reference_v09_sha256":source_sha,"v09_parent_unchanged":True,
 "new_fcstd":str(DEST),
 "new_cut_radius_mm":cut_R,"swept_radius_worst_mm":expected_swept_R,
 "nominal_radial_margin_mm":round(cut_R-expected_swept_R,4),
 "kept_vertical_clearance_at_12_mm":round(top-(7.5+3.8+12),4),
 "existing_vertical_socket_min_web_mm":round(roof_min,4),
 "motion_cases_total":len(comparisons),"motion_cases_colliding":len(collision),
 "bridge_mating_interferences":len(junctions),
 "service_up_states":len(service),
 "core_before_mm3":before,"core_after_mm3":after,
 "core_preservation_vs_V09_pct":round(source_pct,4),
 "source_v09_material_pct_V06":90.93,
 "failure_modes":["No real OEM geometry","12mm hypothetical lift only","+/-2mm XY stress only",
                 "No strength/fatigue or retained closure","No water-tight seal or electricity test"],
 "cases":comparisons,
 "service_cases":service
}
(R/"VALIDACION_V10.json").write_text(json.dumps(res,ensure_ascii=False,indent=2))
Path(__file__).with_name("cad_verification.json").write_text(json.dumps({"ok":True,"cases":len(comparisons),"collisions":0,"source_preserved":True}))
print(json.dumps({k:v for k,v in res.items() if k not in ("cases","service_cases","core_before_mm3","core_after_mm3")},ensure_ascii=False))
