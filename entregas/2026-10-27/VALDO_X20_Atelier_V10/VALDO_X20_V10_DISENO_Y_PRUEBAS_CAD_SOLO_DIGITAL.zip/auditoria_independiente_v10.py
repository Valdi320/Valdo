# -*- coding: utf-8 -*-
"""Independent acceptance V10: compare old V09 against V10 with SAME stress matrix.
Tests are synthetic, not OEM kinematics; require evidence of boundary rejection.
"""
from pathlib import Path
import FreeCAD as App, Part
from FreeCAD import Vector
import json,hashlib
R=Path("/var/home/Valdi/Documentos/X20ProAbierto/Valdo/research/2026-10-25-xiaomi-x20-pro/cad/diseno_industrial_v10_20261027")
p09=R.parent/"diseno_industrial_v09_20261027/VALDO_X20_V09_NUCLEO_CON_ALIVIOS_CONCEPTUAL.FCStd"
p10=R/"VALDO_X20_V10_DESPEJE_LATERAL_NUCLEO_NO_FABRICAR.FCStd"
files={"V09":p09,"V10":p10}
targets={}
components={}
original_hash={key:hashlib.sha256(p.read_bytes()).hexdigest() for key,p in files.items()}
for version,path in files.items():
 doc=App.openDocument(str(path))
 doc.recompute()
 names=["NucleoSector"+str(i) for i in range(1,5)]
 names+=["V07PuenteShell"+str(i) for i in range(1,5)]
 names+=["V07PuenteCore1","V07PuenteCore4","V09PasarelaAlta2","V09PasarelaAlta3"]
 targets[version]={n:doc.getObject(n).Shape.copy() for n in names}
 components[version]={n:doc.getObject(n).Shape.copy() for n in ("MopPadL","MopPadR","MopHubL","MopHubR")}
 assert all(not x.isNull() and x.isValid() for x in [*targets[version].values(),*components[version].values()])
 assert all(len(targets[version]["NucleoSector"+str(i)].Solids)==1 for i in range(1,5))
 App.closeDocument(doc.Name)
pose=[]
for dx in (-2,-1,0,1,2):
 for dy in (-2,-1,0,1,2):
  for lift in (11,12,12.5,13,13.5,14):
   pose.append((dx,dy,lift))
# Extra stress ±3 at 12mm to probe beyond declared horizontal tolerance.
for dx in (-3,3):
 for dy in (-3,-2,-1,0,1,2,3):
  pose.append((dx,dy,12))
for dy in (-3,3):
 for dx in (-2,-1,0,1,2):
  pose.append((dx,dy,12))
assert len(pose)==174,len(pose)
rows=[]
for version in ("V09","V10"):
 for side in ("L","R"):
  for dx,dy,lift in pose:
   moved=[(name,components[version][name].copy()) for name in ("MopPad"+side,"MopHub"+side)]
   hits=[]
   for name,shape in moved:
    shape.translate(Vector(dx,dy,lift))
    for target,shape_target in targets[version].items():
     if not shape.BoundBox.intersect(shape_target.BoundBox):continue
     amount=shape.common(shape_target).Volume
     if amount>.001:hits.append({"source":name,"target":target,"volume_mm3":round(amount,5)})
   rows.append({"version":version,"side":side,"dx_mm":dx,"dy_mm":dy,
    "lift_mm":lift,"collides":bool(hits),"overlap_sum_mm3":round(sum(z["volume_mm3"] for z in hits),6),
    "hits":hits})
def select(version,limit_xy,lifts):
 return [row for row in rows if row["version"]==version and abs(row["dx_mm"])<=limit_xy and abs(row["dy_mm"])<=limit_xy and row["lift_mm"] in lifts]
summary={}
for version in files:
 bylift={}
 for lift in (11,12,12.5,13,13.5,14):
  part=select(version,2,(lift,))
  bylift[str(lift)]={"cases":len(part),"colliding":sum(z["collides"] for z in part),"max_overlap_mm3":max(z["overlap_sum_mm3"] for z in part)}
 extended=[z for z in rows if z["version"]==version and (abs(z["dx_mm"])==3 or abs(z["dy_mm"])==3)]
 summary[version]={"by_lift":bylift,"extended_plus_minus3_at_12":{"cases":len(extended),"colliding":sum(z["collides"] for z in extended)}}
# The acceptance window is explicitly ±2 XY and no higher than 12 mm lift. Outside it failure is allowed and reported.
pass_window=[x for x in rows if x["version"]=="V10" and abs(x["dx_mm"])<=2 and abs(x["dy_mm"])<=2 and x["lift_mm"] in (11,12)]
assert len(pass_window)==100
assert all(not x["collides"] for x in pass_window),[x for x in pass_window if x["collides"]][:2]
control=[x for x in rows if x["version"]=="V09" and abs(x["dx_mm"])<=2 and abs(x["dy_mm"])<=2 and x["lift_mm"]==12]
assert len(control)==50
assert any(x["collides"] for x in control),"Baseline must show known V09 flaw in extended envelope"
assert original_hash=={key:hashlib.sha256(p.read_bytes()).hexdigest() for key,p in files.items()}
document={
 "ok":True,"scope":"INDEPENDENT_STRESS_NOT_OEM",
 "V09_V10_verified_hashes_unchanged":original_hash,
 "test_count":len(rows),"poses_per_model_per_mop":len(pose),
 "pass_window":{"XY_mm":"+/-2","lift_mm":[11,12],"v10_cases":len(pass_window),"v10_collisions":0,
 "v09_at_lift12_collisions":sum(z["collides"] for z in control)},
 "per_version":summary,"all_rows":rows,
 "warnings":["No physical measurements for wheel/mop travel","No validated actual joint strengths",
 "No accepted design above lift12 at >=1.2 mm vertical clearance",
 "Parent V09 untouched; V10 remains nonmanufacturable"]
}
(R/"AUDITORIA_INDEPENDIENTE_V10.json").write_text(json.dumps(document,ensure_ascii=False,indent=2))
Path(__file__).with_name("cad_verification.json").write_text(json.dumps({"ok":True,"v10_pass_window":len(pass_window),"negative_baseline":True,"total":len(rows)}))
print(json.dumps({"ok":True,"cases":len(rows),"V09":summary["V09"],"V10":summary["V10"],"pass":document["pass_window"]},ensure_ascii=False))
