# Entrega del integrador V10 — 27/10/2026

**PARA CONSULTA, sin comunicación confirmada con compañeros.** Área nueva exclusiva `cad/diseno_industrial_v10_20261027/`. No sobrescribir sus fuentes ni interpretar las geometrías como piezas OEM.

## Decisión geométrica digital

Del candidato V09 al V10 se amplía de R49,5 a R51,05 mm el vaciado de núcleo junto a ambas mopas; se conserva el corte vertical hasta z24,5 mm. El barrido de referencia supone dos mopas de R47 mm en (-95, ±65), ±2 mm XY y elevación ≤12 mm. Se modela margen R51,05−(47+sqrt(8))=1,2216 mm y margen vertical 1,2 mm.

La comparación independiente de **696 casos** detectó 4/50 contactos con V09 a elevación 12 mm y 0/50 en V10; a 13,5 mm aparecen contactos en 50/50 poses: explícitamente rechazado. Se gastó un 0,6658% de volumen adicional del núcleo V09 sin cambiar su altura de anclaje.

Las dos pasarelas traseras de V09 y seis puentes de V07 quedan preservados. No se han creado cierres de retención, ni alterado el diseño del responsable de pomos/cierres, ni se han colocado piezas reales de suspensión/transmisión.

## Solicitud para los demás equipos

- **Cierres:** revisar captura positiva de las pasarelas traseras y las cuatro juntas de carrocería con sus márgenes actuales; ningún puente está autorizado para cargar tensión sin prueba.
- **Suspensión y transmisión:** aportar M25-27/M40-44, posición de carcasa y barridos; no extrapolar el centro/radio ficticios de mopas a las ruedas.
- **Cableado/inalámbrico:** validar zonas de mazo y de carga respecto a los nuevos huecos, sin adoptar WPT sin FOD, termometría y protecciones reales.
- **Metrología:** medir **M29** (ascenso de mopas) y origen de coordenadas M40, incluyendo tolerancias y orientación física, antes de intentar carrera mayor.

Documentación: `CAD/diseno_industrial_v10_20261027/README.md`, `AUDITORIA_INDEPENDIENTE_V10.json` y `VALIDACION_V10.json`. No se ha fabricado, comprado ni energizado nada.

**Siguiente salto de alto retorno:** medir el movimiento real de mopas y diseño de acoplamiento; si el recorrido fuese ≥13,5 mm, sustituir las uniones del núcleo trasero por un nuevo camino de carga, no seguir comiendo pared al anclaje actual.
