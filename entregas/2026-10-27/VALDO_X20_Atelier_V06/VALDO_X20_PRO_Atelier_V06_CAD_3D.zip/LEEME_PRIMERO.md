# VALDO X20 Pro — Atelier V06
## Entrega de diseño industrial, 27 de octubre de 2026

**Estado: conceptual y no fabricable todavía.** Estos modelos no reconstruyen el interior OEM con cotas reales. No deben usarse como instrucciones para fabricar o instalar componentes sin ingeniería adicional.

### Archivos que abrir

- `VALDO_X20_V06_SHOWCASE.FCStd`: vista exterior, colores y cámara preparados. **Abrir primero.**
- `VALDO_X20_V06_SERVICIO_EXPLOTADO.FCStd`: tapa levantada 119 mm para exposición y mecánica visible. La separación de 119 mm no es un movimiento diseñado ni validado.
- `VALDO_X20_V06_EXTERIOR_VISUAL_NO_FABRICAR.step`: geometría exterior para interoperabilidad CAD.
- `VALDO_X20_V06_COMPLETO_CONCEPTUAL_NO_FABRICAR.step`: conjunto de piezas de concepto para intercambio.
- `VALDO_X20_V06_presentation.png`: lámina de presentación.
- `VALDO_X20_V06_showcase.png` y `VALDO_X20_V06_servicio.png`: capturas reales de FreeCAD GUI.
- `build_v06.py`: generador reproducible que crea el maestro geométrico inicial.
- `geometry_report.json`, `validacion_de_entrega_v06.json`: evidencia nativa y comprobaciones.

### Qué se ha conseguido

96 sólidos CAD de concepto, carcasa exterior modular en cuatro sectores, tapa cuadranteada y compuerta de mantenimiento, faldón/parachoques, torreta LDS visual, ruedas, mopas/cepillos, bandejas, batería y ventilación conceptuales. Las piezas modeladas tienen envolvente individual XYZ inferior a 256 mm en su orientación CAD, pero **eso no demuestra que sean imprimibles**. Se verificó en FreeCAD 1.1.4 la validez de formas, envolvente total del robot (350 mm de diámetro y hasta 97 mm alto) y la reapertura visual de ambas vistas.

### Qué falta para que sea ingeniería profesional fabricable

1. Registro M40-M44, ruedas, LDS, mopas, ópticas, puerto de estación, fijaciones y pack conservado, con incertidumbre y marcos de coordenadas recuperables.
2. Integración dimensional sin colisiones reales de cartuchos, suspensión, transmisión, cierres y canalización desarrolladas por los otros equipos.
3. Piezas impresas: uniones robustas, tolerancias por material, orientación, fatiga, termomecánica, sellado y envejecimiento.
4. Diseño de seguridad y ensayos físicos de agua, electricidad, bumper, ruedas y carga.
5. Certificar entrada/salida de módulos, desmontaje/reparación y coste de fabricación.

No se han añadido al robot real cambios físicos ni se ha modificado el CAD maestro compartido.
