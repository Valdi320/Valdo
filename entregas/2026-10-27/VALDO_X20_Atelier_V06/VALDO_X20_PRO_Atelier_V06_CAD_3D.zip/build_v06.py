# -*- coding: utf-8 -*-
"""VALDO X20 · Atelier V06 - Diseño industrial paramétrico conceptual, 100% SOLO escenario.

Geometría hecha con OpenCascade/FreeCAD 1.1.4; NO reconstrucción OEM, NO imprimir.
El modelo de configuración es de referencia (en lugar de cotas interiores falsas).
"""
from pathlib import Path
from math import radians,cos,sin,pi
import json, hashlib
import FreeCAD as App
import Part
from FreeCAD import Vector

HERE=Path(__file__).resolve().parent
if (HERE/"VALDO_X20_Atelier_V06_BASE.FCStd").exists():
    raise RuntimeError("V06 ya existe: no sobrescribir")
S={
 "external_diameter_mm":350.0, "external_height_limit_mm":97.0,
 "shell_radius_mm":174.2, "lid_radius_mm":171.9,
 "quarter_gap_mm":1.35,
 "radial_wall_mm":5.0,
 "lidar_x_mm":52.0, "lidar_y_mm":0.0,
 "hatch_center_x_mm":-72.0, "hatch_width_x_mm":116.0,
 "hatch_width_y_mm":118.0,
 "hatch_corner_radius_mm":19.0,
 "concept_wheel_radius_mm":30.0,
 "concept_wheel_y_mm":127.0,
 "concept_mop_radius_mm":47.0,
}
doc=App.newDocument("VALDO_X20_Atelier_V06_BASE")
G={}
items=[]
def group(key,label):
    ob=doc.addObject("App::DocumentObjectGroup",key);ob.Label=label;G[key]=ob;return ob
group("G00","00 · NO FABRICAR · Escenario CAD · Interiores sin medir")
group("G01","01 · Carroceria modular FFF · 4 sectores imprimibles")
group("G02","02 · Tapa y compuerta mantenimiento · 4 cuadrantes")
group("G03","03 · LDS y optica · Ventanas y sellos conceptuales")
group("G04","04 · Parachoques y sensores · Faja perimetral")
group("G05","05 · Chasis · Camino de cargas conceptual")
group("G06","06 · Transmision y rodadura · Proxies NO OEM")
group("G07","07 · Cepillos, mopas, aspiracion · Proxies NO OEM")
group("G08","08 · Electronica, bateria y depo · Bandejas extraibles")
group("G09","09 · Acceso y piezas cautivas · Sin tornillos metal")
group("G10","10 · Acabados visuales · Detalles de identificacion")
group("G11","11 · Registro de interfaces y cambios necesarios")
spec=doc.addObject("Spreadsheet::Sheet","ParametrosAtelier")
spec.Label="Parametros Atelier V06 - escenario, no OEM"
spec.set("A1","Parametro");spec.set("B1","Valor [mm]");spec.set("C1","Estado")
for idx,(key,val) in enumerate(S.items(),2):
    spec.set("A"+str(idx),key);spec.set("B"+str(idx),str(val))
    spec.set("C"+str(idx),"PUBLICADO" if "external_" in key else "ESCENARIO")
    try:spec.setAlias("B"+str(idx),key)
    except Exception:pass

def feat(name,label,shape,g,color,role,visible=True,detail=""):
    if not (not shape.isNull() and shape.Volume>0.005 and shape.isValid()):
        raise RuntimeError("OCC invalido "+name)
    obj=doc.addObject("PartDesign::Feature",name)
    obj.Label=label;obj.Shape=shape
    G[g].addObject(obj)
    obj.addProperty("App::PropertyString","Estado","Trazabilidad");obj.Estado="ESCENARIO_NO_OEM"
    obj.addProperty("App::PropertyString","Funcion","Trazabilidad");obj.Funcion=role
    obj.addProperty("App::PropertyString","Observacion","Trazabilidad");obj.Observacion=detail
    obj.addProperty("App::PropertyBool","AptoFabricacion","Trazabilidad");obj.AptoFabricacion=False
    obj.addProperty("App::PropertyString","ColorHex","Apariencia");obj.ColorHex=color
    obj.addProperty("App::PropertyBool","MostrarEnHero","Apariencia");obj.MostrarEnHero=visible
    items.append({"name":name,"label":label,"volume_mm3":round(shape.Volume,2),
         "material_color":color,"purpose":role,"showcase":visible,"group":g,
         "bbox_mm":[round(shape.BoundBox.XLength,2),round(shape.BoundBox.YLength,2),round(shape.BoundBox.ZLength,2)]})
    return obj

def cylinder(r,h,x,y,z,axis=None):
    return Part.makeCylinder(r,h,Vector(x,y,z),axis if axis is not None else Vector(0,0,1))
def ring(ro,ri,z,h,x=0,y=0):
    return cylinder(ro,h,x,y,z).cut(cylinder(ri,h+2,x,y,z-1))
def torus(R,r,x,y,z):
    return Part.makeTorus(R,r,Vector(x,y,z),Vector(0,0,1))
def prism(l,w,h,x,y,z):
    return Part.makeBox(l,w,h,Vector(x,y,z))
def rounded_panel(cx,cy,l,w,r,z,h):
    # shape de union geometrica exacta: piezas exteriores con esquinas de radio uniforme
    if r<=0 or 2*r>=min(l,w):raise ValueError("rounded shape arguments")
    sh=prism(l-2*r,w,h,cx-(l-2*r)/2,cy-w/2,z)
    parts=[prism(l,w-2*r,h,cx-l/2,cy-(w-2*r)/2,z)]
    for sx in (-1,1):
      for sy in (-1,1):
        parts.append(cylinder(r,h,cx+sx*(l/2-r),cy+sy*(w/2-r),z))
    return sh.multiFuse(parts).removeSplitter()
def quadrant(side_u,side_v,z,height):
    # Angular module sectors from 45-degree-rotated local frame;
    # seam not on forward sensor, approximate bounding 250 x 250 for FFF.
    extend=193
    half=S["quarter_gap_mm"]/2
    xmin=half if side_u>0 else -extend
    ymin=half if side_v>0 else -extend
    width=extend-half
    local=prism(width,width,height,xmin,ymin,z)
    local.rotate(Vector(0,0,0),Vector(0,0,1),45)
    return local
def ar(x,y,r):
    return (x+r*cos(y),r*sin(y))
# Cortes de tapa: abertura LDS, servicio trasero. Reutilizar sin afirmar geometria OEM.
ldshole=cylinder(35.5,12,S["lidar_x_mm"],0,70)
hatchhole=rounded_panel(S["hatch_center_x_mm"],0,120,122,21,70,14)
deck=cylinder(171.8,3.5,0,0,73.5).cut(ldshole).cut(hatchhole)
body=ring(174.25,168.45,18.5,55.5)
bumper=ring(174.75,171.05,34.5,10.5)
belt=ring(173.2,171.25,30.8,2.2)
lower=ring(172.5,167.8,16.2,2.3)
for q,(u,v) in enumerate(((1,1),(1,-1),(-1,-1),(-1,1)),1):
    cutbox=quadrant(u,v,12,80)
    feat("PanelCarroceria%d"%q,"Exterior / Modulo %d - segmentado"%q,
        body.common(cutbox),"G01","#F0F2F0","cuarto de carcasa desmontable",
        True,"separacion angular ilustrativa; dimensiones de ensamblaje por confirmar")
    feat("PanelTapa%d"%q,"Tapa / Cuadrante %d - desmontable"%q,
        deck.common(cutbox),"G02","#E4E8E9","cuarto de tapa modular 256x256 candidata",
        True,"aberturas conceptuales para torreta y acceso tecnico")
    feat("BumperSector%d"%q,"Parachoques de servicio / Sector %d"%q,
        bumper.common(cutbox),"G04","#18232C","faja oscura con modulos sustituibles",
        True,"paragolpes conceptual, requiere barrido, sensores de contacto y retorno")
    feat("UnionBajo%d"%q,"Faldon inferior / Cuadrante %d"%q,
        lower.common(cutbox),"G01","#2F3F4A","faldon protegido modular")
    feat("LinealPerimetral%d"%q,"Franja estructural / Sector %d"%q,
        belt.common(cutbox),"G04","#637885","cinta intermedia que separa cuerpo/banda")
# Borde de tapa acabado: línea de junta sombreada.
for q,(u,v) in enumerate(((1,1),(1,-1),(-1,-1),(-1,1)),1):
    seal=ring(171.2,170.0,73.8,1.0).common(quadrant(u,v,73.0,3.0))
    feat("LineTopSeal%d"%q,"Junta superior segmentada %d"%q,
         seal,"G10","#182832","junta visual separada por cuadrantes",True,
         "elastomero/estanqueidad no ensayados")
# Placa abatible de servicio individual y borde de goma, no torsion ni bisagra aún.
cx=S["hatch_center_x_mm"]
feat("JuntaHatch","Anillo de junta de compuerta",rounded_panel(cx,0,119,121,20,73.8,3.2).cut(
    rounded_panel(cx,0,113.5,115.5,17.5,73,5)),"G02","#26343A",
    "sello desmontable visual",True,"solo un marco; interfaz real pendiente")
feat("CubiertaHatch","Compuerta superior baterías/electrónica",
    rounded_panel(cx,0,113.2,115.2,17.4,75.5,2.3),"G02","#B6C0C6",
    "acceso de servicio local",True,"sin sistema de estanqueidad ni ranuras definidas")
# Líneas de agarre/tirador: rebaje visual sin mecanismo
feat("HatchFinger","Tirador acanalado semienrasado",
    rounded_panel(-127,0,6.5,33,2.2,78.0,.7),"G10","#263944",
    "ergonomia de extracción")
# Marca/icono geométrico minimalista, sin letras y sin fuentes externas.
for i,(yy,sz) in enumerate(((-12,17),(-3,22),(7,14)),1):
    bar=prism(2.4,sz,.4,-84,yy,77.83)
    feat("MarcaLinea%d"%i,"Firma visual / segmento %d"%i,bar,"G10",
        "#00A9B4","identidad conceptual VALDO",True)
# LDS: soporte independiente de tapa con bisel metalizado y cristal oscuro
lx=S["lidar_x_mm"]
feat("LDSBase","Collarín independiente del LiDAR",ring(34,29.4,76.5,6.6,lx,0),
     "G03","#374451","puente de navegación separado de la tapa",True,
     "campo laser de visión y altura sin medir")
feat("LDSTower","Tambor cilíndrico LiDAR protegido",
     cylinder(31.2,13,lx,0,80.6),"G03","#263846","carcasa torreta",True)
feat("LDSBisel","Anillo fino anodizado del LiDAR",
     torus(30.3,.9,lx,0,93.6),"G03","#02BCC8","detalle de estanqueidad conceptuoso",True)
feat("LDSTop","Cristal/tapa óptica oscuro",
     cylinder(29.3,1.35,lx,0,94.1),"G03","#152631","ventana de sensores no certificada",True)
feat("LDSEmblem","Botón central / referencia alineación LiDAR",
     cylinder(6.5,.5,lx,0,95.45),"G03","#5A7080","marcador visual pequeño",True)
# Indicador de estado y botón encendido
feat("PowerBase","Panel encendido / base oscura",
     cylinder(12,1.25,113,0,77),"G10","#243842","panel mando principal",True)
feat("PowerRing","Anillo estado de encendido",
     ring(8.6,6.9,78.1,.43,113,0),"G10","#02CBD0","indicador de luz conceptual",True)
feat("PowerTouch","Botón central integrado",
     cylinder(6.2,.4,113,0,78.12),"G10","#E6EFF0","botonera enrasada",True)
# Bumper frontal protegido, banda de sensores en frontal X+
feat("FrontOptic","Óptica frontal protectora oval provisional",
     cylinder(16,2.1,171.3,0,51.5,Vector(1,0,0)),
     "G04","#08171F","ventana frontal sustituible",
     True,"no es estructura real del sensor")
feat("FrontOpticRing","Anillo óptico frontal",
     ring(14.2,12.4,0,1.0).copy().transformGeometry(App.Matrix()) if False else
     cylinder(13.5,1.1,173.35,0,51.5,Vector(1,0,0)).cut(
         cylinder(11.6,1.6,173.1,0,51.5,Vector(1,0,0))),
     "G04","#04ABB5","detalle de proteccion optica")
# Ventanas laterales de sensor, parte del bumper, no posiciones OEM
for i,yy in enumerate((-108,108),1):
    feat("SideSensor%d"%i,"Ventana perimetral de sensor lado %d"%i,
         prism(4,14,13,124,yy-7,41),"G04","#132532",
         "sensor pared/obstáculo hipotético",True)
# Ventilación discreta superior: cortes de apariencia, no agujeros de agua
for i in range(6):
    y=-28+i*11
    shape=rounded_panel(120,y,13,3.7,1.3,76.9,.5)
    feat("VentTop%d"%i,"Rejilla decorativa %d"%i,shape,"G10",
         "#6D8790","futura ventilacion bajo filtro")
# Chasis (solo para vista de servicio), partes imprimibles separables
chassisring=ring(157.5,145,20.5,7.4)
for q,(u,v) in enumerate(((1,1),(1,-1),(-1,-1),(-1,1)),1):
    frag=chassisring.common(quadrant(u,v,20.0,12.0))
    feat("NucleoSector%d"%q,"Nucleo estructural / Cuadrante %d"%q,
         frag,"G05","#455F6D","segmento nervado previsto",False,
         "interfaz de cierre de los cuadrantes pendiente")
for i,ang in enumerate((0,45,90,135,180,225,270,315),1):
    # vigueta liviana entre uniones, sin diseñar todas las interferencias reales
    beam=prism(96,7.6,6.2,36,-3.8,24.4)
    beam.rotate(Vector(0,0,0),Vector(0,0,1),ang)
    feat("Radial%d"%i,"Nervio modular del núcleo %d"%i,beam,
         "G05","#536D7C","nervio no dimensionado",False)
for side,sgn in (("L",1),("R",-1)):
    wheel_y=sgn*S["concept_wheel_y_mm"]
    axle_dir=Vector(0,1,0)
    # y center -> start wheel position
    tyre=cylinder(30,20,14,wheel_y-10,34,axle_dir)
    feat("Neumatico"+side,"Tracción / rueda "+side,tyre,"G06","#1B222B",
         "rodadura de poliuretano a verificar",False)
    hub=cylinder(15.8,1.5,14,wheel_y+(10 if sgn>0 else -11.5),34,axle_dir)
    feat("Buje"+side,"Buje / núcleo de rueda "+side,hub,"G06","#C1D0D5",
         "casquillo imprimible candidato",False)
    feat("AroBuje"+side,"Acento buje / "+side,
         cylinder(12,1.6,14,wheel_y+(10 if sgn>0 else -11.6),34,axle_dir),"G06",
         "#05AFC1","hub de alto contraste",False)
    # Carcasa del cartucho tiene forma redondeada, con eje conceptual sin cotas OEM
    feat("Cartucho"+side,"Cartucho reparable / "+side,
         rounded_panel(3,wheel_y,57,45,11,40,20.2),"G06",
         "#768995","caja del conjunto de traccion",False)
# Rueda loca anterior (parte inferior)
feat("CasterMount","Cuna de rueda loca de acceso inferior",
     rounded_panel(122,0,43,48,12,13.4,8),"G06","#728893",
     "asiento de caster futuro",False)
feat("CasterBall","Esfera de apoyo/caster sintético",
     Part.makeSphere(13.2,Vector(122,0,15)),"G06","#1D2733","apoyo giratorio NO OEM",False)
# Retenedores laterales decorativos, auto-cautivos hipotéticos (sin mecanismo definido)
for idx,angle in enumerate((42,138,222,318),1):
    x=148*cos(radians(angle));y=148*sin(radians(angle))
    feat("LockMarker%d"%idx,"Marcador de cierre cautivo %d"%idx,
         cylinder(7.2,1,x,y,77.01),"G09","#293D47",
         "asiento de cierre impreso solo como marcador",False)
    feat("LockPin%d"%idx,"Indexación de cierre %d"%idx,
         cylinder(2.9,.35,x,y,78.03),"G09","#06AFC0",
         "marca de orientacion del cierre",False)
# Mopas y cepillos bajo base, como volúmenes CSG, no contacto real
for suffix,yy in (("L",+65),("R",-65)):
    feat("MopPad"+suffix,"Mopa modular reemplazable "+suffix,
         cylinder(47,3.8,-95,yy,7.5),"G07","#39ACB5",
         "plato/fibra intercambiable, movilidad real pendiente",False)
    feat("MopHub"+suffix,"Enganche de mopa "+suffix,
         cylinder(15,4.8,-95,yy,11.3),"G07","#2B5366",
         "cierre magnetico/mecanico solo idea",False)
feat("BrushRoll","Cepillo central radial",
     cylinder(11.5,145,15,-72.5,16.3,Vector(0,1,0)),
     "G07","#D96B36","cepillo principal necesita cotas OEM",False)
feat("BrushChannel","Canal desmontable del cepillo",
     rounded_panel(15,0,37,165,11,20.7,8),"G07","#607987",
     "conducto aspiración visual",False)
feat("SideBrushCore","Núcleo cepillo lateral",
     cylinder(19.5,3.8,114,-98,9),"G07","#D0903E",
     "cepillo lateral visual",False)
for angle in (0,120,240):
    spatula=prism(21,5,1.3,116,-100.5,10.3)
    spatula.rotate(Vector(114,-98,0),Vector(0,0,1),angle)
    feat("SideBrushArm%d"%angle,"Brazo escoba lateral %d"%angle,spatula,
         "G07","#D39D5D","cerdas/dureza sin ensayar",False)
# Componentes del interior: contenedores con radios de esquina
feat("BatteryCassette","Casete batería cerrado y extraíble",
     rounded_panel(-55,-7,98,68,10,42,24),"G08","#2D343F",
     "bateria OEM cerrada, dimensiones desconocidas",False)
feat("BatteryMark","Etiqueta de seguridad batería",
     rounded_panel(-55,-7,63,22,5,66.1,.5),"G08","#EFC66B",
     "sólo etiqueta de identificación",False)
feat("MainPCBCassette","Bandeja electronica propia",
     rounded_panel(5,12,122,86,8,62.5,2.9),"G08","#166D61",
     "sin tornillos metal; soporte separado y aislado",False)
feat("MainPCBShield","Protector no estructural de placa",
     rounded_panel(5,12,106,68,8,65.5,1.3),"G08","#3A9884",
     "proteccion electrónica, temperatura pendiente",False)
feat("BlowerPod","Cassette turbina aspiración",
     cylinder(29,25,52,82,36),"G08","#655A86",
     "turbina no medida",False)
feat("BlowerVent","Rejilla estilizada turbina",
     ring(26,21,61,1,52,82),"G08","#2C344B",
     "entrada aire sin flujo calculado",False)
feat("TankPod","Deposito extraible limpiable",
     rounded_panel(-110,0,64,76,15,38,27),"G08","#C1D0D9",
     "volumen de tanque ficticio",False)
feat("TankLatch","Retencion de deposito",
     rounded_panel(-146,0,6,29,2,65.1,2),"G08","#263E48",
     "gancho/radio de servicio pendiente",False)
# Bases documentales de procedencia, para no atribuir falsas cotas.
for name,txt in (
 ("RuedasPendientes","M25-M27, M40-M44 por lado, sin metrología del ejemplar"),
 ("LDSReferencia","Sensor LDS de referencia conceptual, M28/M78/M79 pendientes"),
 ("BateriaReferencia","Pack original cerrado, no abrir ni probar con CAD"),
 ("EstacionReferencia","La estación D102-JZEU se modelará al medir acoplamiento"),
 ("Limites","CAD de estudio, no se certifica encaje, carga, fatiga, sellos ni funcionamiento")):
    p=doc.addObject("App::DocumentObjectGroup",name)
    p.Label="[PENDIENTE] "+name
    p.addProperty("App::PropertyString","Descripcion","Evidencia")
    p.Descripcion=txt
    G["G11"].addObject(p)
doc.recompute()
# Se admite ensamblaje visual con posibles solapes, no se afirma encaje.
report=[]
maximum_z=-1
for i in items:
    o=doc.getObject(i["name"])
    assert o.Shape.isValid()
    maximum_z=max(maximum_z,o.Shape.BoundBox.ZMax)
    report.append({"name":o.Name,"minz":o.Shape.BoundBox.ZMin,"maxz":o.Shape.BoundBox.ZMax})
assert 84<=maximum_z<=97.0,maximum_z
doc.saveAs(str(HERE/"VALDO_X20_Atelier_V06_BASE.FCStd"))
App.closeDocument(doc.Name)
# Native doc reopening roundtrip
doc=App.openDocument(str(HERE/"VALDO_X20_Atelier_V06_BASE.FCStd"));doc.recompute()
assert all(doc.getObject(it["name"]).Shape.isValid() and doc.getObject(it["name"]).Shape.Volume>0 for it in items)
count=len(items)
App.closeDocument(doc.Name)
evidence={"ok":True,"kind":"INDUSTRIAL_STYLING_CONCEPT_NOT_OEM",
  "part_count":count,"groups":len(G),"max_height_mm":round(maximum_z,3),
  "diameter_reference_mm":350,
  "quarter_segmentation":True,"camera_ready":False,
  "limits":["No medidas reales interiores Xiaomi","No viabilidad de materiales demostrada",
            "No fatiga, sellos ni mantenimiento ensayados","Colisiones entre componentes NO validadas globalmente"],
  "objects":items}
(HERE/"geometry_report.json").write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
Path(__file__).parent.joinpath("cad_verification.json").write_text(json.dumps(
    {"ok":True,"parts":count,"native_reopened":True,"scope":"CONCEPT_NOT_OEM"}))
print(json.dumps({"ok":True,"parts":count,"max_height_mm":maximum_z,"document":str(HERE/"VALDO_X20_Atelier_V06_BASE.FCStd")},ensure_ascii=False))
