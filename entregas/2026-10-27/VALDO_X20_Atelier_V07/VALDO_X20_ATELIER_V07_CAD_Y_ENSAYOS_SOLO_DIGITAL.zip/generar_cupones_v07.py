# -*- coding: utf-8 -*-
"""Seis cupones pequeños para calibrar ajustes radiales en impresión FFF.
Son piezas autónomas de banco, NO fijaciones del robot OEM.
"""
import FreeCAD as App
import Part,Mesh,hashlib,json,csv
from FreeCAD import Vector
from pathlib import Path
ROOT=Path("/var/home/Valdi/Documentos/X20ProAbierto/Valdo/research/2026-10-25-xiaomi-x20-pro/cad/diseno_industrial_v07_20261027")
DIR=ROOT/"cupones_ajuste_fff"
DIR.mkdir(exist_ok=True)
output=DIR/"VALDO_V07_3_PAREJAS_CALIBRACION.FCS td".replace(" ","")
output=Path(output)
if output.exists():raise FileExistsError(output)
doc=App.newDocument("VALDO_V07_CUPONES_DE_AJUSTE")
doc.Label="VALDO X20 · Banco de 3 ajustes — NO OEM"
meta=doc.addObject("App::DocumentObjectGroup","Alcance")
meta.Label="Solo geometría de calibración. No aprobar manufactura ni resistencia."
records=[]
radius=1.5
width=30.0
depth=16.0
base_h=4.0
pin_height=7.3
pin_overlap=.5
female_h=8.0
female_depth=7.2
assembly_clearance_z=.2
clearances=[.20,.35,.50]
for i,c in enumerate(clearances):
    xcenter=i*47.
    male_plate=Part.makeBox(width,depth,base_h,Vector(xcenter-width/2,-depth/2,0))
    pegs=[Part.makeCylinder(radius,pin_height,Vector(xcenter+shift,0,base_h-pin_overlap)) for shift in (-8,8)]
    male=male_plate.multiFuse(pegs).removeSplitter()
    assert male.isValid() and len(male.Solids)==1 and male.Volume>100
    female_y=38
    female_blank=Part.makeBox(width,depth,female_h,Vector(xcenter-width/2,female_y-depth/2,0))
    holes=[Part.makeCylinder(radius+c,female_depth,Vector(xcenter+shift,female_y,-.35))
        for shift in (-8,8)]
    female=female_blank.cut(holes[0].multiFuse(holes[1:])).removeSplitter()
    assert female.isValid() and len(female.Solids)==1 and female.Volume>100
    # En posición de ensamblaje, female bottom z4.2; pin tip z10.8, female roof z? se acepta hueco de salida
    fem_assembled=female.copy()
    fem_assembled.translate(Vector(0,-female_y,base_h+assembly_clearance_z))
    collision=male.common(fem_assembled).Volume
    assert collision<.0002,(c,collision)
    # Comprobación de sensibilidad negativa: un agujero <radio espiga> debe detectar choque.
    if i==0:
       tight_blank=Part.makeBox(width,depth,female_h,Vector(xcenter-width/2,-depth/2,base_h+.2))
       tight_holes=[Part.makeCylinder(radius-.2,7.5,Vector(xcenter+shift,0,base_h-.15)) for shift in (-8,8)]
       negative=tight_blank.cut(tight_holes[0].multiFuse(tight_holes[1:]))
       negative_collision=male.common(negative).Volume
       assert negative_collision>1.0,negative_collision
    for label,shape,kind in (("M",male,"espiga"),("F",female,"alojamiento")):
      name=f"Coupon_{kind}_{int(c*100):02d}"
      obj=doc.addObject("PartDesign::Feature",name)
      obj.Label=f"Cupon {kind} · holgura radial {c:.2f} mm"
      obj.Shape=shape
      meta.addObject(obj)
      obj.addProperty("App::PropertyFloat","HolguraRadial","Ajuste")
      obj.HolguraRadial=c
      obj.addProperty("App::PropertyString","ColorHex","Apariencia")
      obj.ColorHex="#00AABB" if label=="M" else "#C5D1D8"
      obj.addProperty("App::PropertyBool","AptoRobot","Aviso")
      obj.AptoRobot=False
      dest=DIR/(name+".stl")
      if dest.exists():raise FileExistsError(dest)
      Mesh.export([obj],str(dest))
      assert dest.exists() and dest.stat().st_size>300, (name,dest.stat().st_size)
      test=Mesh.Mesh(str(dest))
      # computed mesh counts valid; FreeCAD OCC remains authoritative
      triangles=test.CountFacets
      assert triangles>20,(name,triangles)
      records.append({"coupon":name,"type":kind,"radial_clearance_mm":c,
        "diametral_clearance_mm":2*c,"mass_grams":None,"mesh_triangles":triangles,
        "stl_bytes":dest.stat().st_size,"stl_sha256":hashlib.sha256(dest.read_bytes()).hexdigest()})
doc.recompute()
doc.saveAs(str(output))
App.closeDocument(doc.Name)
doc=App.openDocument(str(output))
expected_names=[f"Coupon_{t}_{j:02d}" for t in ("espiga","alojamiento") for j in (20,35,50)]
assert all(doc.getObject(name) is not None and doc.getObject(name).Shape.isValid() for name in expected_names),expected_names
App.closeDocument(doc.Name)
report={
 "ok":True,"kind":"COUPON_FIT_TRIAL_NOT_FABRICABLE_ROBOT_PART",
 "pairs":len(clearances),"parts":len(records),
 "negative_tight_hole_collision_mm3":round(negative_collision,3),
 "cad_nominal_assembly_clearance_z_mm":assembly_clearance_z,
 "cad_assembly_collision_free":True,
 "materials":[ "PCTG","PETG","PA"],"materials_tested_physically":False,
 "printer_used":None,"nominal_pin_diameter_mm":2*radius,
 "stl_files":records,"document":str(output),
 "limitations":["No ensayo de comportamiento en puente real",
                "No precisión funcional OEM","Sin retención, resistencia ni durabilidad probada",
                "Geometrías STL solo para probar proceso de impresión, no para montar en robot"]}
(DIR/"informe_cupones.json").write_text(json.dumps(report,indent=2,ensure_ascii=False))
Path(__file__).parent.joinpath("cad_verification.json").write_text(json.dumps({"ok":True,"pairs":3,"stl_files":6,"negative_control":True}))
print(json.dumps({"ok":True,"pairs":3,"stl_files":6,"tight_interference_mm3":negative_collision},ensure_ascii=False))
