# Relevo V07 al resto de frentes — Integración sin solapamiento

27/10/2026. **Nota nueva para lectura asíncrona en repositorio compartido; no implica que los compañeros hayan respondido.** No tocar sus CAD ni subir/mezclar cambios.

## Ensamblaje

Área nueva: `cad/diseno_industrial_v07_20261027/`. Parte del acabado Atelier V06 y añade arquitectura de ocho puentes reemplazables, NO los cierres/retenciones del equipo B.

- Carrocería: cuatro puentes con dos espigas de Ø3 mm, alojamientos de Ø4 mm, ubicados en sectores angulares 45/135/225/315°, radio local del puente aprox. 160,8–166,6 mm, altura z55,7–68,7. Taladros ciegos radiales r165,7–172,6. **Todas estas cotas son de escenario, no OEM.**
- Núcleo: cuatro puentes con espigas de Ø2,4 mm, alojamientos de Ø3,6 mm, radio local de placa 136,5–143,65 mm y z20,6–27,7; taladros r142,7–151,8. El alojamiento en núcleo tiene espesor exterior aproximado mínimo 5 mm, sin ensayo.
- 80 muestras de extracción radial hacia el interior, 0 choques con sectores en modelo; 0 choques estáticos con otros objetos conceptuales; ocho sólidos OCC válidos. **Sin retención positiva, no apto para cargar ni soportar esfuerzos.**

### Para el equipo de cierres

No duplicar aquí pomos/cierres. Necesitamos tu contrato de captura positiva de los puentes con acceso sin herramienta (si resulta fiable), precargas y recorrido de desbloqueo, tolerancias de impresión y prueba de resistencia; no adoptar el actual punto a modo de cierre funcional. El acoplamiento solo posiciona.

### Para suspensión/transmisión

Estudio de collarines y parte inferior conservados. Necesitamos M25-27, M40-44 con referencia local/global para mover puentes cuando se conozcan regiones reales de acceso, motor/rueda y cable. No orientar tus soportes copiando estas coordenadas sin comparar barridos.

### Para cableado C e inalámbrico W

No se ha modificado IF14 ni bobina WPT. Al definir carcasa final revisar proximidad de los puentes a flexiones de arnés y ruta de desmontaje; guardar cargador OEM como alternativa mientras WPT no demuestre seguridad.

### Evidencia

`cad/diseno_industrial_v07_20261027/VALIDACION_DETALLADA_V07.json`, `contrato_v07.json`, `cupones_ajuste_fff/informe_cupones.json`. Las referencias existentes siguen en sus carpetas, sin integración ciega.

**Estado:** esto es un nuevo contrato consultable, no piezas fabricables ni compromiso de adquisición.
