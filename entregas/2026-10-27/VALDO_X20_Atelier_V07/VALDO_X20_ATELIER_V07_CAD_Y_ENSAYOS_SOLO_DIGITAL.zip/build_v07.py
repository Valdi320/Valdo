# -*- coding: utf-8 -*-
"""V07: conectores de posicionamiento y reparto de carga en la estructura segmentada.
Sin fijar tornilleria/pomos de otros compañeros; solo modelo de ensayo geométrico.
No sustituye mediciones OEM ni ensayos de impresión.
"""
import FreeCAD as App
import Part,math,json,hashlib
from FreeCAD import Vector
from pathlib import Path
ROOT=Path("/var/home/Valdi/Documentos/X20ProAbierto/Valdo/research/2026-10-25-xiaomi-x20-pro/cad/diseno_industrial_v07_20261027")
ORIGINAL=Path("/var/home/Valdi/Documentos/X20ProAbierto/Valdo/research/2026-10-25-xiaomi-x20-pro/cad/diseno_industrial_v06_20261027/VALDO_X20_V06_SHOWCASE.FCStd")
DEST=ROOT/"VALDO_X20_V07_INTEGRACION_ESTRUCTURAL_BASE.FCStd"
if DEST.exists():raise FileExistsError(DEST)
assert ORIGINAL.is_file()
hash_prev=hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
cfg={
 "shell": {
   "local_plate_umin_mm":160.8,"local_plate_umax_mm":166.6,
   "half_width_mm":18.0,"z_bottom_mm":55.7,"z_height_mm":13.0,
   "pin_r_mm":1.5,"pocket_r_mm":2.0,"pin_umin_mm":165.8,
   "pin_length_mm":5.9,"pocket_umin_mm":165.7,"pocket_length_mm":6.9,
   "pin_tangential_mm":11.0,"pin_z_mm":62.2,
   "original_inner_wall_radius_mm":168.45,"original_outer_wall_radius_mm":174.25,
   "ring_z_min_mm":18.5,"ring_z_max_mm":74.0
 },
 "core": {
   "local_plate_umin_mm":136.5,"local_plate_umax_mm":143.65,
   "half_width_mm":15.0,"z_bottom_mm":20.6,"z_height_mm":7.1,
   "pin_r_mm":1.2,"pocket_r_mm":1.8,"pin_umin_mm":142.85,
   "pin_length_mm":8.0,"pocket_umin_mm":142.7,"pocket_length_mm":9.1,
   "pin_tangential_mm":9.8,"pin_z_mm":24.15,
   "original_inner_wall_radius_mm":145.0,"original_outer_wall_radius_mm":157.5,
   "ring_z_min_mm":20.5,"ring_z_max_mm":27.9
 },
 "seam_angles_degrees":[45,135,225,315],
 "sample_clearance_inward_mm":[0,.5,1,2,3,4,5,6,7,8],
 "material_assumptions":"FFF polymer unselected; pocket enlargement is only geometric candidate",
 "OEM_position_proven":False,"fabrication_approved":False
}
doc=App.openDocument(str(ORIGINAL))
doc.Label="VALDO X20 V07 | Almacen CAD. Juntas modulares (no fabricar)"
parent=doc.addObject("App::DocumentObjectGroup","V07Integracion")
parent.Label="V07 | Uniones estructurales y puentes de posicionamiento"
subgroups={}
for key,label in [("shell","V07 · Carrocería · alineadores reemplazables"),("core","V07 · Núcleo · puentes desmontables")]:
 g=doc.addObject("App::DocumentObjectGroup","V07Grupo"+key.title())
 g.Label=label;parent.addObject(g);subgroups[key]=g
source_panels={
 "shell":[doc.getObject("PanelCarroceria"+str(i)) for i in (1,2,3,4)],
 "core":[doc.getObject("NucleoSector"+str(i)) for i in (1,2,3,4)]
}
assert all(all(p is not None for p in seq) for seq in source_panels.values())
sha_shapes={group:{o.Name:round(o.Shape.Volume,5) for o in seq} for group,seq in source_panels.items()}
orig_shapes={group:[o.Shape.copy() for o in seq] for group,seq in source_panels.items()}
# Nuevo estudio sin reafirmar cotas; parámetros de escenario controlados por generador Python y properties.
couplers={}
angles=cfg["seam_angles_degrees"]
def transform(shape,ang):
 sh=shape.copy()
 sh.rotate(Vector(0,0,0),Vector(0,0,1),ang)
 return sh
def make_bridge(spec,ang):
 u=spec["local_plate_umin_mm"];v=spec["local_plate_umax_mm"]
 t=spec["half_width_mm"]
 plate=Part.makeBox(v-u,2*t,spec["z_height_mm"],Vector(u,-t,spec["z_bottom_mm"]))
 pegs=[]
 pockets=[]
 for sign in (-1,1):
  tangent=sign*spec["pin_tangential_mm"]
  cyl=Part.makeCylinder(spec["pin_r_mm"],spec["pin_length_mm"],
                       Vector(spec["pin_umin_mm"],tangent,spec["pin_z_mm"]),
                       Vector(1,0,0))
  hole=Part.makeCylinder(spec["pocket_r_mm"],spec["pocket_length_mm"],
                       Vector(spec["pocket_umin_mm"],tangent,spec["pin_z_mm"]),
                       Vector(1,0,0))
  pegs.append(transform(cyl,ang))
  pockets.append(transform(hole,ang))
 bridge=transform(plate,ang).multiFuse(pegs).removeSplitter()
 assert not bridge.isNull() and bridge.isValid() and bridge.Volume>10
 return bridge,pegs,pockets
# Cuatro interfaces geométricas, cada una atraviesa dos cuadrantes con un pequeño puente.
base_shapes={}
row=[]
coupler_pins={}
for kind in ("shell","core"):
 spec=cfg[kind]
 base_shapes[kind]={o.Name:o.Shape.copy() for o in source_panels[kind]}
 couplers[kind]=[]
 for i,angle in enumerate(angles,1):
  bridge,pegs,pockets=make_bridge(spec,angle)
  # Cortar alojamientos de todos los sectores, las piezas adyacentes los comparten.
  for o in source_panels[kind]:
   for hole in pockets:
    bb=o.Shape.BoundBox
    if bb.intersect(hole.BoundBox):
     cut=o.Shape.cut(hole).removeSplitter()
     if not cut.isValid() or cut.Volume<5:raise RuntimeError("hole corrupted "+o.Name)
     o.Shape=cut
  name="V07Puente"+kind.title()+str(i)
  part=doc.addObject("PartDesign::Feature",name)
  part.Label="Puente "+kind+" / Junta "+str(i)+" · "+str(angle)+"°"
  part.Shape=bridge;subgroups[kind].addObject(part)
  for key,value in (
    ("Estado","ESCENARIO_NO_FABRICAR"),("Rol","ALINEACION_SIN_RETENCION"),
    ("MaterialCandidato","PCTG/PETG/PA segun ensayo"),("IF","IF04 por verificar")):
   part.addProperty("App::PropertyString",key,"Contrato");setattr(part,key,value)
  part.addProperty("App::PropertyBool","AptoFabricacion","Contrato")
  part.AptoFabricacion=False
  part.addProperty("App::PropertyString","ColorHex","Apariencia")
  part.ColorHex="#10BFCB" if kind=="shell" else "#E7A15F"
  part.addProperty("App::PropertyBool","MostrarEnHero","Apariencia")
  part.MostrarEnHero=False
  couplers[kind].append(part)
  coupler_pins[name]=pegs
  row.append({"id":name,"angle_deg":angle,"type":kind,"solid_mm3":round(bridge.Volume,4),
              "pins":len(pegs),"radial_clearance_mm":round(spec["pocket_r_mm"]-spec["pin_r_mm"],3),
              "nominal_axial_peg_tip_mm":spec["pin_umin_mm"]+spec["pin_length_mm"],
              "pocket_end_mm":spec["pocket_umin_mm"]+spec["pocket_length_mm"]})
# Move spokes away from seam to preserve radial inward extraction path of core bridges.
for i in range(1,9):
 obj=doc.getObject("Radial"+str(i))
 assert obj is not None and obj.Shape.isValid()
 pivot=Vector(0,0,0)
 sh=obj.Shape.copy()
 sh.rotate(pivot,Vector(0,0,1),22.5)
 obj.Shape=sh
 obj.Observacion += " | V07 orientado +22.5° para preservar extracción de alineadores"
# Mecanismo de retención externo no modelado; dejar explícito en el árbol.
status=doc.addObject("App::DocumentObjectGroup","V07Bloqueadores")
status.Label="V07 | Retención por cierres, medidas y materiales: PENDIENTE"
parent.addObject(status)
for j,(nm,message) in enumerate([
 ("Retencion","Ningún puente se retiene axialmente. Cierres y pomos son del responsable externo."),
 ("Holguras","0.5/0.6 mm son radio geométrico nominal, no holguras FFF validadas."),
 ("OEM","Ni las cotas internas ni los puntos de anclaje se han medido en el X20 Pro."),
 ("Fuerzas","No existe prueba de rigidez, vibración, impacto, humedad o fatiga."),
 ("Servicio","La liberación de resortes/cableado exige procedimientos de seguridad del equipo."),
 ]):
 obj=doc.addObject("App::DocumentObjectGroup","V07Condicion"+str(j))
 obj.Label="[BLOQUEADO] "+nm
 obj.addProperty("App::PropertyString","Requisito","Contrato");obj.Requisito=message
 status.addObject(obj)
# Auditoría con OCC: ninguno de los puentes debe atravesar la carcasa o núcleo ya vaciados.
doc.recompute()
collisions=[];samples=[];max_extra=0
env=Part.makeCylinder(175,97,Vector(0,0,0))
for kind in ("shell","core"):
 spec=cfg[kind]
 pieces=source_panels[kind]
 for bridge in couplers[kind]:
  if bridge.Shape.cut(env).Volume>.01:raise RuntimeError("Bridge outside ext envelope")
  for body in pieces:
   vol=bridge.Shape.common(body.Shape).Volume
   if vol>.005:collisions.append((bridge.Name,body.Name,round(vol,6)))
  ang=int(row[next(idx for idx,a in enumerate(row) if a["id"]==bridge.Name)]["angle_deg"])
  axis=Vector(math.cos(math.radians(ang)),math.sin(math.radians(ang)),0)
  for delta in cfg["sample_clearance_inward_mm"]:
   shape=bridge.Shape.copy()
   shape.translate(axis*(-delta))
   vol=sum(shape.common(o.Shape).Volume for o in pieces)
   samples.append({"part":bridge.Name,"inward_mm":delta,"overlap_mm3":round(vol,7),
        "clear":vol<.005})
if collisions:raise RuntimeError("COLLISION "+repr(collisions))
if not all(s["clear"] for s in samples):
 raise RuntimeError("EXTRACTION_COLLISION "+repr([s for s in samples if not s["clear"]][:15]))
# Analytic design walls, not measured manufactured min walls.
for kind,spec in (("shell",cfg["shell"]),("core",cfg["core"])):
 t=spec["pin_tangential_mm"]
 R=spec["original_outer_wall_radius_mm"]
 end=spec["pocket_umin_mm"]+spec["pocket_length_mm"]
 roof=math.sqrt(R*R-t*t)-end
 cfg[kind]["approx_roof_wall_mm"]=round(roof,4)
 if roof<1:raise RuntimeError("Roof wall too thin "+str((kind,roof)))
 cfg[kind]["pin_nominal_clearance_radius_mm"]=spec["pocket_r_mm"]-spec["pin_r_mm"]
 # bridge inward longitudinal minimum clearance at tangential far edge.
 mindist=spec["original_inner_wall_radius_mm"]-math.hypot(spec["local_plate_umax_mm"],spec["half_width_mm"])
 cfg[kind]["min_coupler_body_radial_clearance_estimate_mm"]=round(mindist,4)
 if mindist<.05:raise RuntimeError("Outside wall bridge intersect "+str((kind,mindist)))
 # Verify bridge pegs intended to enter parent material before pocketing.
 for i,part in enumerate(couplers[kind]):
  for pin in coupler_pins[part.Name]:
   intended=sum(pin.common(orig).Volume for orig in orig_shapes[kind])
   if intended<4:raise RuntimeError("Peg has no target stock: "+part.Name)
# preserve upstream bytes
bridge_names={kind:[p.Name for p in couplers[kind]] for kind in ("shell","core")}
doc.saveAs(str(DEST))
App.closeDocument(doc.Name)
assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()==hash_prev
reload=App.openDocument(str(DEST));reload.recompute()
for kind in ("shell","core"):
 for name in bridge_names[kind]:
  p=reload.getObject(name)
  assert p and p.Shape.isValid() and p.Shape.Volume>1
App.closeDocument(reload.Name)
report={
 "ok":True,"schema":"VALDO_ATELIER_V07","concept_only":True,
 "parent_v06":str(ORIGINAL),"parent_sha256":hash_prev,
 "v07_fcstd":str(DEST),"physical_parts_added":len(row),
 "alignment_pegs_added":sum(r["pins"] for r in row),
 "revised_solid_groups":list(source_panels),
 "design_parameters":cfg,"rows":row,
 "nominal_insertion_collisions":collisions,"extraction_samples":samples,
 "all_extraction_samples_clear":all(s["clear"] for s in samples),
 "cad_reopened":True,"parent_unchanged":True,
 "limits":["Sin retención/seguro de puentes","No valores OEM",
 "Barrido local de extracción no equivale a servicio global","No prueba de tolerancia impresa/agua/fatiga"]
}
(ROOT/"validacion_mecanica_v07.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
(ROOT/"contrato_v07.json").write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
Path(__file__).parent.joinpath("cad_verification.json").write_text(
 json.dumps({"ok":True,"model_valid":True,"new_pieces":len(row),"new_pegs":len(row)*2,
             "samples":len(samples),"collisions":len(collisions),"roof_shell":cfg["shell"]["approx_roof_wall_mm"],
             "roof_core":cfg["core"]["approx_roof_wall_mm"]}))
print(json.dumps({"ok":True,"new_pieces":len(row),"pins":len(row)*2,"samples":len(samples),
  "min_roof_mm":{k:cfg[k]["approx_roof_wall_mm"] for k in ("shell","core")}},ensure_ascii=False))
