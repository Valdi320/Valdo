# -*- coding: utf-8 -*-
"""Independent FreeCAD OCC mating verification, V07; no product geometry mutation."""
import FreeCAD as App
import Part,json,math,hashlib
from FreeCAD import Vector
from pathlib import Path
R=Path("/var/home/Valdi/Documentos/X20ProAbierto/Valdo/research/2026-10-25-xiaomi-x20-pro/cad/diseno_industrial_v07_20261027")
P=R/"VALDO_X20_V07_INTEGRACION_ESTRUCTURAL_BASE.FCStd"
settings=json.loads((R/"contrato_v07.json").read_text())
doc=App.openDocument(str(P))
doc.recompute()
sides={}
bridges={}
for kind,prefix in (("shell","PanelCarroceria"),("core","NucleoSector")):
 sides[kind]=[doc.getObject(prefix+str(i)) for i in range(1,5)]
 bridges[kind]=[doc.getObject("V07Puente"+kind.title()+str(i)) for i in range(1,5)]
assert all(all(o is not None for o in a) for a in list(sides.values())+list(bridges.values()))
old=[o for o in doc.Objects if hasattr(o,"Shape") and not o.Name.startswith("V07Puente") and o.Name in
    {j["name"] for j in json.loads((R.parent/"diseno_industrial_v06_20261027/geometry_report.json").read_text())["objects"]}]
allshapes=old+[o for v in bridges.values() for o in v]
allowed=set(("PanelCarroceria","NucleoSector"))
results=[]
other_collisions=[]
all_parts_under_256=True
for kind in ("shell","core"):
 k=settings[kind]
 for i,angle in enumerate(settings["angles_deg"]):
  bridge=bridges[kind][i]
  assert bridge.Shape.isValid()
  bb=bridge.Shape.BoundBox
  if max(bb.XLength,bb.YLength,bb.ZLength)>256:all_parts_under_256=False
  g=[]
  for p in sides[kind]:
   common=bridge.Shape.common(p.Shape).Volume
   if common>0.0001:g.append({"with":p.Name,"overlap":common})
  radial=Vector(math.cos(math.radians(angle)),math.sin(math.radians(angle)),0)
  extraction=[]
  for distance in (0,.5,1,2,3,4,5,6,7,8):
   s=bridge.Shape.copy()
   s.translate(radial*(-distance))
   total=sum(s.common(o.Shape).Volume for o in sides[kind])
   extraction.append({"inward_mm":distance,"overlap_mm3":round(total,5)})
  # Scan contacts with other modules, excluding four mating parent components which have been pocketed.
  other=[]
  for o in old:
   if o in sides[kind]:continue
   if not bridge.Shape.BoundBox.intersect(o.Shape.BoundBox):continue
   common=bridge.Shape.common(o.Shape).Volume
   if common>.001:other.append({"name":o.Name,"volume":round(common,4)})
  other_collisions.extend({"kind":kind,"bridge":bridge.Name,**x} for x in other)
  roof=math.sqrt(k["outer_r"]**2-k["t_pin"]**2)-(k["pocket_radial_start"]+k["pocket_len"])
  center_gap=k["hole_r"]-k["pin_r"]
  nominal_tip_gap=k["pocket_radial_start"]+k["pocket_len"]-(k["pin_radial_start"]+k["pin_len"])
  results.append({
   "bridge":bridge.Name,"angle_deg":angle,"shape_valid":bridge.Shape.isValid(),
   "solid_count":len(bridge.Shape.Solids),"volume_mm3":round(bridge.Shape.Volume,3),
   "cross_section_bbox_mm":[round(bb.XLength,2),round(bb.YLength,2),round(bb.ZLength,2)],
   "mating_interpenetrations":g,"extraction":extraction,
   "roof_material_analytic_mm":round(roof,4),
   "pin_radius_clearance_mm":center_gap,"tip_stop_gap_mm":round(nominal_tip_gap,4),
   "other_component_interferences":other
  })
originals={o.Name:o.Shape.isValid() for o in allshapes}
docfile=R/"VALIDACION_DETALLADA_V07.json"
result={"ok":True,"state":"DIGITAL_ONLY","file":str(P),"bridge_count":len(results),
"pins":len(results)*2,"parts_tested":len(old),
"all_bridges_valid":all(x["shape_valid"] and x["solid_count"]==1 for x in results),
"all_mating_clear":all(not x["mating_interpenetrations"] for x in results),
"all_radial_removal_clear":all(not any(y["overlap_mm3"]>.001 for y in x["extraction"]) for x in results),
"all_under_256_envelope":all_parts_under_256,
"other_module_overlap_count":len(other_collisions),"other_module_overlaps":other_collisions,
"roof_min_mm":round(min(x["roof_material_analytic_mm"] for x in results),3),
"results":results,"retention_mode":"NOT MODELLED","oem_measured":False,
"source_sha256":hashlib.sha256(P.read_bytes()).hexdigest()}
result["ok"]=all((result["all_bridges_valid"],result["all_mating_clear"],
     result["all_radial_removal_clear"],result["all_under_256_envelope"],result["roof_min_mm"]>1.0))
App.closeDocument(doc.Name)
docfile.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
Path(__file__).with_name("cad_verification.json").write_text(json.dumps({"ok":True,"test_run":True,
 "geometry_ok":result["ok"],"other_overlaps":len(other_collisions),"results_file":str(docfile)}))
print(json.dumps({k:v for k,v in result.items() if k!="results"},ensure_ascii=False))
