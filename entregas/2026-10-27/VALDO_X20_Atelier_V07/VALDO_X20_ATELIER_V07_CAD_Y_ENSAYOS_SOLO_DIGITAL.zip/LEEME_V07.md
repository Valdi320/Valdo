# VALDO X20 — Atelier V07 · Diseño industrial + uniones mecánicas

27-10-2026 · **SÓLO DEMOSTRADOR DIGITAL, NO FABRICAR PARA EL ROBOT**

## Lo que ha avanzado respecto a V06

- Conserva el diseño de 96 sólidos y la carrocería en cuatro partes, elaborada para su visualización con colores y tapas.
- Añade ocho puentes de posicionamiento desmontables: cuatro para la carrocería (a z 55,7–68,7 mm) y cuatro para el núcleo (a z 20,6–27,7 mm). Cada puente posee dos espigas radiales y su correspondiente alojamiento ciego, sin fijaciones metálicas.
- Corrige ocho nervios radiales (+22,5° de orientación en el modelo) para no obstaculizar el acceso geométrico a los puentes inferiores. Estas orientaciones SON DE ESCENARIO.
- La interfaz V07 está localizada en los cuatro encuentros de sectores (45°, 135°, 225° y 315°). No se reclama compatibilidad con la distribución real OEM.

## Auditoría mecánica nativa

En `VALIDACION_DETALLADA_V07.json` se documentan ocho sólidos de puente con geometría FreeCAD válida; **0 interpenetraciones** con los paneles perforados; recorrido radial de extracción hacia dentro desde 0 a 8 mm, 10 posiciones por puente (**80 estados**); **0 interferencias** de puentes con el resto de los sólidos del escenario. El espesor de material exterior mínimo estimado geométricamente en el extremo del taladro ciego es 1,302 mm (NO cálculo de resistencia, NO dimensión medida).

Datos de demostración:

| Zona | Espiga Ø | Alojamiento Ø | Holgura radial nominal | Cubierta exterior |
|---|---:|---:|---:|---:|
| Carrocería | 3,0 mm | 4,0 mm | 0,50 mm | Estimación geométrica, sin ensayar |
| Núcleo | 2,4 mm | 3,6 mm | 0,60 mm | Estimación geométrica, sin ensayar |

**Los puentes no tienen retención positiva**: podrían soltarse por vibración, gravedad o servicio. Los cierres manuales (pomos, sobrecentro y captura) pertenecen al otro equipo. Este CAD no los reemplaza y no está aprobado para imprimir o usar en el X20 real.

## Cupones de banco de ajuste FFF

`cupones_ajuste_fff/` incluye un modelo visible FreeCAD, seis STL separados y tres pares espiga/alojamiento de 0,20, 0,35 y 0,50 mm de **holgura radial nominal**, para calibrar proceso de impresión y material. No son piezas de robot. Esta calibración usa espigas en eje vertical, no acredita igual precisión, orientación de capas o fatiga en las espigas radiales del puente.

## Vistas 3D

- `VALDO_X20_V07_EXTERIOR.FCStd`: la apariencia exterior.
- `VALDO_X20_V07_DESPIECE.FCStd`: tapa desplazada **solo para exposición** y ocho puentes visibles.
- `VALDO_X20_V07_DETALLE_UNIONES_CORREGIDO.FCStd`: vista ampliada de una interfaz y dos puentes.
- `VALDO_X20_V07_lamina_presentacion.png`: comparación visual.
- `VALDO_X20_V07_INTEGRACION_ESTRUCTURAL_BASE.FCStd`: fuente mecánica CAD antes de cambios estéticos de cámara.
- `build_v07.py`: script generador reproducido en carpeta limpia con resultado PASS.
- `puentes_geometricos_SOLO_REFERENCIA/`: ocho STL y un STEP de demostrador, NO habilitación para imprimir piezas funcionales.

Todas las vistas han sido abiertas otra vez en la GUI de FreeCAD 1.1.4, no solamente guardadas con FreeCADCmd.

## Antes de fabricar

Falta metrología M40–M44, M25–M30, M70–M89; una revisión de choques con **los módulos reales**, no solo los proxies; diseño de retención y transmisión de cargas; impresión de cupones; tolerancias corregidas por impresora/material/orientación; pruebas de fuerza, fatiga, humedad y seguridad. No se han alterado archivos V06 ni CAD de otros compañeros.

## Próximo paso de mayor retorno

Especificar a los responsables de cierres las envolventes de puentes V07 y rutas de acceso; después integrar **sus cierres aprobados** sin superponer su trabajo. Con medidas reales, acomodar ruedas/LDS/mopas, estación de carga y conductos. Solo entonces es honesto optimizar FFF y reducir el coste real.
